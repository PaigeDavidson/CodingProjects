###############################
# module: cs3430_s24_hw04.py
# description: CS3430: S24: Assignment 04
# YOUR NAME:
# YOUR A-NUmBER:
###############################
import numpy as np

def simplex(tab):
    """
    Apply the simplex algorithm to the tableaue tab.
    """
    ### your source code
    pass

def get_solution_from_tab(tab):
    in_vars, mat = tab[0], tab[1]
    nr, nc = mat.shape
    sol = {}
    for k, v in in_vars.items():
        sol[v] = mat[k,nc-1]
    sol['p'] = mat[nr-1,nc-1]
    return sol

def display_solution_from_tab(tab):
    sol = get_solution_from_tab(tab)
    for var, val in sol.items():
        if var == 'p':
            print('p\t=\t{}'.format(val))
        else:
            print('x{}\t=\t{}'.format(var, val))



