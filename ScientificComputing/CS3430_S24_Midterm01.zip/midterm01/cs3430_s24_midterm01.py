#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################
# module: cs3430_s24_midterm01.py
# YOUR NAME
# YOUR A-NUMBER
# WRITE THE TIME IT TOOK YOU TO COMPLETE THIS EXAM.
##############################################################

import numpy as np
import numpy.linalg

### put your imports from your previous/current assignments.

### ================ Problem 01 ========================

def solve_lin_sys_with_gje(a, b):
    ### your code here
    pass

### ================ Problem 02 ========================

def solve_lin_sys_with_cramer(A, b):
    ### your code here
    pass

### ================ Problem 03 =========================

def solve_lin_sys_with_bsubst(A, n, b, m):
    ### your code here
    pass

### ================ Problem 04 =========================

def solve_lin_sys_with_fsubst(A, n, b, m):
    ### your code here
    pass

### ================ Problem 05 =========================

def solve_lin_sys_with_lud(A, n, b, m):
    ### your code here
    pass


### ================ Problem 06 =========================

"""
Type your answer to Problem 06 here.
"""

### ================ Problem 07 =========================

"""
Type your answer to Problem 07 here in the form of
the table. Clearly identify the column and row variables.
"""

### ================ Problem 08 =========================

"""
Type your answer to Problem 08 here. Clearly identify 
the column and row variables of the pivot and its value
and explain how you found it.
"""

### ================ Problem 09 =========================

"""
Type your answer to Problem 09 here. Be brief. Do not
write an essay.
"""

### ================= Problem 10 ==========================

def farming_land_allocation():
    ### Set up your tableau by replacing Nones
    ### with appropriate values.
    in_vars = None
    m = None
    tab = None
    ### call simplex
    tab, solved = simplex(tab)
    ### get solution
    sol = get_solution_from_tab(tab)
    ### return it
    return sol
