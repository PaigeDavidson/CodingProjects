######################################################
# module: cs3430_s24_hw01.py
# bugs to vladimir kulyukin in canvas
# YOUR NAME:
# YOUR A-NUMBER:
######################################################

import numpy as np
import numpy.linalg
import random

# ========== Problem 1 ==============

def cs3430_s24_hw_01_prob_1_1():
    A = None ## Your code here
    b = None ## Your code here
    try:
        x = np.linalg.solve(A, b)
    except np.linalg.LinAlgError as e:
        return e
    return A, x, b

def cs3430_s24_hw_01_prob_1_2():
    A = None ## Your code here
    b = None ## Your code here
    try:
        x = np.linalg.solve(A, b)
    except np.linalg.LinAlgError as e:
        return e
    return A, x, b

def cs3430_s24_hw_01_prob_1_3():
    A = None ## Your code here
    b = None ## Your code here    
    try:
        x = np.linalg.solve(A, b)
    except np.linalg.LinAlgError as e:
        return e
    return A, x, b

def cs3430_s24_hw_01_prob_1_4():
    A = None ## Your code here
    b = None ## Your code here    
    try:
        x = np.linalg.solve(A, b)
    except np.linalg.LinAlgError as e:
        return e
    return A, x, b

### ============== Problem 2 ==================

def leibnitz_det(mat):
    ## Your code here
    pass

### ============== Problem 3 ==================

def cramers_rule(A, b):
    ## Your code here
    pass

### ===========================================    
    
              
