#######################################
# module: rmb.py
# description: Romberg Intergration
# ---------------------------------
# bugs to vladimir kulyukin in Canvas
#######################################

import numpy as np

class rmb(object):

    ### The formula is on Slide 08 in Lecture 13 PDF.
    @staticmethod
    def T_k_1(f, a, b, k):
        """
        Trapezoidal Rule of Definite Integral Approximation.
        f is a function; 
        a is the lower boundary of the interval;
        b is the upper boundary of the interval; 
        k is such that n = 2**(k-1), where n is the number of sub-intervals into 
          [a,b] is  partitioned;
        it defines the number of intervals (e.g., k=0, then n=1, k=1, n=2, etc.)
        """
        assert k > 0
        ## your code here
        pass

    @staticmethod
    def R_j_l(f, a, b, j, l):
        """
        Computes the value at the node R[j,l] in the Romberg Lattice
        to approximate the definite integral of f over [a, b] according
        to the formula in Slide 23, Lecture 14.
        """
        ### your code here
        pass
