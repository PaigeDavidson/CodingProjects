#####################################################
# module: cdd.py
# description: Python implementations of some of the
# central divided difference (CDD) formulas
# from Ch. 6 in "Numerical Methods Using MATLAB"
# 4th edition by J. Mathews and K. Fink.
# The PDF of the relevant sections of
# this chapter is included in the zip archive
# of this assignment. I also included it
# in the zip archive of Lecture 12 in Canvas when
# we discussed CDD for the first time.
# ---------------------------------------------
# bugs to vladimir kulyukin in canvas
######################################################

import numpy as np

class cdd(object):

    ### --- CDD of First and Second Derivatives Order 2 ----
    @staticmethod
    def drv1_ord2(f, x, h):
        """
        An implementation of formula 1 in Table 6.3, p. 339 in 
        CDD.pdf. This formula uses CDD to approximate
        f'(x), i.e., derivative 1 (hence drv1 in the name of
        the method), and the estimated error of the approximation
        is O(h^2), where h is the stepsize. Hence, order 2 (ord2) 
        in the name of the method.
        f is a Python function of 1 argument; x is the value
        where we estimate f'(x); h is the step size.
        """
        ### your code here
        pass

    @staticmethod
    def drv2_ord2(f, x, h):
        """
        An implementation of formula 2 in Table 6.3, p. 339 in 
        CDD.pdf. This formula uses CDD to approximate
        f''(x), i.e., derivative 2 (hence drv2 in the name of
        the method), and the estimated error of the approximation
        is O(h^2), where h is the stepsize. Hence, order 2 (ord2) 
        in the name of the method.
        f is a Python function of 1 argument; x is the value
        where we estimate f''(x); h is the step size.
        """
        ### your code here
        pass

    ### --- CDD of First and Second Derivatives Order 4 ----    
    @staticmethod
    def drv1_ord4(f, x, h):
        """
        An implementation of formula 1 in Table 6.4, p. 339 in 
        CDD.pdf. This formula uses CDD to approximate
        f'(x), i.e., derivative 1 (hence drv1 in the name of
        the method), and the estimated error of the approximation
        is O(h^4), where h is the stepsize. Hence, order 4 (ord4) 
        in the name of the method.
        f is a Python function of 1 argument; x is the value
        where we estimate f'(x); h is the step size.
        """
        ### your code here
        pass

    @staticmethod
    def drv2_ord4(f, x, h):
        """
        An implementation of formula 2 in Table 6.4, p. 339 in 
        CDD.pdf. This formula uses CDD to approximate
        f''(x), i.e., derivative 2 (hence drv2 in the name of
        the method), and the estimated error of the approximation
        is O(h^4), where h is the stepsize. Hence, order 4 (ord4) 
        in the name of the method.
        f is a Python function of 1 argument; x is the value
        where we estimate f''(x); h is the step size.
        """
        ### your code here
        pass


    

    

    

    
        
    
