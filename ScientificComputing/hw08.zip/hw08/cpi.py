
#########################################
# module: cpi.py
# description: Pi approximation with the
# Chudnovsky algorithm.
# ----------------------------------------
# bugs to vladimir kulyukin in Canvas.
#########################################

import decimal

class cpi(object):

    @staticmethod
    def binary_split(a, b):
        """
        do the binary splitting of the inteval [a,b] for
        the Chudnovsky algorithm.
        """
        ### your code here.

    @staticmethod
    def arx_real(n, prec=10):
        """
        approximate (arx) the real value of pi by binary splitting on the interval [1, n], n>1,
        with the Chudnovsky algorithm at a given value of precision prec.
        """
        assert n > 1
        decimal.getcontext().prec=prec        
        ### your code here.
