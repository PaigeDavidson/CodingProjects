#################################################
# module: ecf.py
# description: approximation of the number
# E with the continued fraction (cf) on Slide 6
# in Lecture 16.
# ----------------------------------------
# bugs to vladimir kulyukin in Canvas.
##################################################

from rat import rat
import decimal

class ecf(object):

    @staticmethod
    def N_i(i):
        assert i > 0
        """ 
        the i-th numerator in the continued fraction for
        e on Slide 6 in Lecture 16.
        """
        ### your code here

    @staticmethod
    def D_i(i):
        """ 
        the i-th denominator in the continued fraction for
        e on Slide 6 in Lecture 16.
        """
        ### your code here


    @staticmethod
    def cf_rat(i):
        """
        The ratio component of the continued fraction of
        e on Slide 6 in Lecture 16.
        """
       ### your code here

    @staticmethod
    def arx_rat(i):
        """
        approximates (arx) e with the i-th continued fraction on Slide 6
        in Lecture 16 computed as a ratio (rat).
        """
        ### your code here

    @staticmethod
    def arx_real(i, prec=20):
        """
        approximates (arx) e with the i-th continued fraction on Slide 6
        in Lecture 16 computed as a real.
        """
        ### your code here
