
#############################################
# Module: nra.py
# Description: Newton-Raphson Algorithm
# bugs to vladimir kulyukin in canvas.
#############################################

import numpy as np
import math
from tiny_de import tiny_de

class nra(object):

    @staticmethod
    def zr1(text, x0, num_iters=3):
        # your code here
        pass

    @staticmethod
    def zr2(text, x0, delta=0.0001):
        # your code here
        pass

    @staticmethod
    def check_zr(text, zr):
        tde = tiny_de()
        f = tde.lambdify(tde.parse(text))
        return np.allclose(f(zr), 0.0)
