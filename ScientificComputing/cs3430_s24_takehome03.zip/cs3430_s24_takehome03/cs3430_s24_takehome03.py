##############################################################
# module: cs3430_s24_takehome03.py
# description: submission file for CS 3430: S24: Takehome 03
# -----------------------------------------------------------
#
# YOUR NAME:
# YOUR A#
#
#
# bugs to vladimir kulyukin in canvas
##############################################################

### I commented out my imports. You can add your imports
### as needed.

import unittest
import math
import numpy as np
import scipy as sp
import scipy.stats
#from rmb import rmb
import matplotlib.pyplot as plt
from PIL import Image
#from bin_id3 import bin_id3

### =================== Problem 1 =============================

def fourier_coeffs(f, num_coeffs=10, a=-math.pi, b=math.pi, romb=7):
    ### your code here
    pass

### =================== Problem 2 =============================

def nth_partial_sum(x, acoeffs, bcoeffs):
    assert len(acoeffs) == len(bcoeffs)+1
    # your code here
    pass

def plot_function_and_nth_partial_sum(f, f_def_str, num_coeffs=10, num_points=1000,
                                      a=-math.pi, b=math.pi, romb=7):
    # your code here
    pass

### ================== Problem 4 ===========================

def gen_lcg(a, b, m, n, x0=0):
    # your code here
    pass

### ================== Problem 5 ============================

def gen_xorshift_32(a, b, c, n, x0=1):
    # your code here
    pass
        
### ================== Problem 6 ============================

def __int_to_rgb(i):
    """
    convert a positive integer into an red-green-blue 3-tuple.
    """
    def __get_byte(i, byte_index):
        i = int(i)
        return ((i >> (8 * byte_index)) % 256 + 256) % 256
    r = __get_byte(i, 0) / 255
    g = __get_byte(i, 1) / 255
    b = __get_byte(i, 2) / 255
    return (r, g, b)

def make_lcg_pix(a, b, m, n, seed=11235813):
    """
    returns an numpy array (i.e., np.array) of RGB 3-tuples extracted with 
    __int_to_rgb(i) from LCG random numbers generated with gen_lcg(a,b,m,n,x0=seed).
    """
    assert n > 0
    # your code here
    pass

def make_random_pil(pix, w, h, n, name='random_pil', save_flag=True):
    """
    makes a random PIL image and saves/shows it.
    """
    ### pix must be an np.array
    assert isinstance(pix, np.ndarray)
    img_pix = pix.reshape(h, w, 3)
    pil_img = Image.fromarray(img_pix, 'RGB')
    if save_flag:
        pil_img.save(name + '.png')
    else:
        pil_img.show()

### ========================== Problem 07 =======================================        

def make_xorshift_32_pix(a, b, c, n, seed=1):
    """
    returns an numpy array, i.e., np.array, of RGB 3-tuples extracted with 
    __int_to_rgb(i) from 32-bit XORShift random numbers generated with 
    gen_xorshift_32().
    """
    assert n > 0
    # your code here
    pass

### ========================= Problem 08 =======================================

def make_equal_probs_table(lower=1, upper=2):
    """
    ranges from lower to upper in increments from 1 and
    assings the probability of 1/(upper-lower+1) to each
    number in the range.
    """
    nums = [i for i in range(lower, upper+1)]
    n = upper - lower + 1
    probs = {}
    for x in nums:
        probs[x] = 1/n
    return probs

def get_coin_flip_seqs(num_coin_flips):
    assert num_coin_flips > 0
    # your code here
    pass

def get_coin_flip_seqs_aux(num_coin_flips):
    assert num_coin_flips >= 0
    # your code here
    pass

def is_sufficiently_knuth_random(str_digit_seq, probs):
    # your code here
    pass

def get_sufficiently_knuth_random_coin_flip_seqs(num_coin_flips):
    assert num_coin_flips > 0
    # your code here
    pass

def get_insufficiently_knuth_random_coin_flip_seqs(num_coin_flips):
    assert num_coin_flips > 0
    # your code here
    pass

### ========================= Problem 09 =======================================

def get_die_throw_seqs(num_die_throws):
    assert num_die_throws > 0
    # your code here
    pass

def get_die_throw_seqs_aux(num_die_throws):
    assert num_die_throws >= 0    
    # your code here
    pass

def get_sufficiently_knuth_random_die_throw_seqs(num_die_throws):
    assert num_die_throws > 0
    # your code here
    pass

def get_insufficiently_knuth_random_die_throw_seqs(num_die_throws):
    assert num_die_throws > 0
    # your code here
    pass
        
### ========================= Problem 10 =======================================

def learn_bin_id3_dt(examples_file_path):
    # your code here
    pass

def display_bin_id3_dt(dtr):
    # your code here
    pass

def gain(examples, target_attrib, attrib, avt):
    # your code here
    pass

def entropy(examples, target_attrib, avt):
    # your code here
    pass

### ========================= Problem 11 =======================================

"""
Type your answers to Problem 11 below. Huffman Trees can be typeset as follows:

           {A,B}:2
            /\
           /  \
       {A}:1  {B}:1

Let's assume, in order to reduce typing, that a left branch always emits 0
and a right branch -- 1. Thus, in the above Huffman tree, encode(A) = 0 and
encode(B) = 1; decode(0) = A and decode(1) = B.

a)

b)

c)
"""

