#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################
# module: cs3430_s24_midterm02.py
# YOUR NAME
# YOUR A-NUMBER
# WRITE THE TIME IT TOOK YOU TO COMPLETE THIS EXAM.
##############################################################

### put your imports from your previous/current assignments.
### These are the imports that I used to implement my solutions.
### Modify these as you see fit.
"""
from   tiny_de     import tiny_de     ## homework 05
from   nra import nra                 ## homework 05
from   cs3430_s24_hw06 import *       ## homework 06
from   cdd import cdd                 ## homework 07
from   rmb import rmb                 ## homework 07
from   rxp import rxp                 ## homework 07
from   rat import rat                 ## homework 08
from   picf import picf               ## homework 08
from   ecf  import ecf                ## homework 08
from   cpi import cpi                 ## homework 08
import sympy
import sympy.utilities
import math
from PIL import Image
import decimal
"""

### ================ Problem 01 ========================

def diff_file(file_path):
    ### your code here
    pass

### ================ Problem 02 ========================

def zero_root(poly_text, num_iters=5):
    ### your code here
    pass

### ================ Problem 03 =========================

def detect_pil_edge_pixels(in_imgpath, out_imgpath, default_delta=1.0, magn_thresh=20):
    ### your code here
    pass

### ================ Problem 04 =========================

def cdd_drv1_ord2(f, x, h):
    ### your code here
    pass

def cdd_drv1_ord4(f, x, h):
    ### your code here
    pass

### ================ Problem 05 =========================

def cdd_drv2_ord2(f, x, h):
    ### your code here
    pass

def cdd_drv2_ord4(f, x, h):
    ### your code here
    pass

### ================ Problem 06 =========================

def romberg_integral(f, a, b, j, l):
    ### your code here
    pass

### ================ Problem 07 =========================

def richardson_2(av_2n, av_n):
    ### your code here
    pass

### ================ Problem 08 =========================

def e_cont_frac_rat(i):
    assert i >= 0
    ### your code here
    pass

def e_cont_frac_real(i, prec=20):
    assert i >= 0
    decimal.getcontext().prec=prec
    ### your code here
    pass

### ================  Problem 09 =========================

def pi_cont_frac_rat(i):
    assert i >= 0
    ### your code here
    pass

def pi_cont_frac_real(i, prec=20):
    assert i >= 0
    decimal.getcontext().prec=prec
    ### your code here
    pass

### ================= Problem 10 ==========================

def chudnovsky_pi(n, prec=20):
    ### your code here
    pass


