##############################################
# module: seqrand.py
# description: tests of sequence randomness
# YOUR NAME
# YOUR A#
# --------------------------------------------
# bugs to vladimir kulyukin in canvas.
##############################################

from prng import prng
import scipy.stats
import random

def get_transcendental_str(fp):
    with open(fp, 'r') as infs:
        _str = infs.readline()
        return ''.join([c for c in list(_str.strip()) if c != ' '])
    
def get_mantissa(fp):
    return get_transcendental_str(fp)[2:]

def chisquare_str_digit_seq(str_digit_seq, seq_start=0, seq_end=10):
    assert 0 <= seq_start < seq_end <= len(str_digit_seq)
    ### your code here
    pass

def chisquare_mersenne_twister(pval_lower=0.1,
                               pval_upper=0.9,
                               seq_len=10, num_experiments=10):
    rand_seq_count = 0
    ### your code here
    return rand_seq_count, rand_seq_count / num_experiments
        
        
