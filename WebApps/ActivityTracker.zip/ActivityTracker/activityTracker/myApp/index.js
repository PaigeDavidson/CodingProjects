for(let name of activity.querySelectorAll("input[type=string]")){
    name.addEventListener("change", (e) => {
        
    })
}