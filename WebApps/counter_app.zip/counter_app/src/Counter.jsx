import { useState } from 'react'

export function Counter() {
    const [count, setCount] = useState(0);

    function increment(){
       setCount(count + 1);
    }
    function decrement(){
        setCount(count - 1)

    }
    function incrementFive(){
        setCount(count + 5);
    }
    function decrementFive(){
        setCount(count - 5);
    }
    function multiply(){
        setCount(count * 2);
    }
    function divide(){
        setCount(count / 2);
    }
    return (
      <div>
        <div>{count}</div>
        <div>
            <button id = "button" onClick={increment}>Increment by One</button>
        </div>
        <div>
            <button onClick={decrement}>Decrement by One</button>
        </div>
        <div>
            <button onClick={incrementFive}>Increment By 5</button>
        </div>
        <div>
            <button onClick={decrementFive}>Decrement by 5</button>
        </div>
        <div>
            <button onClick={multiply}>Mulpiply by 2</button>
        </div>
        <div>
            <button onClick={divide}>Divide by 2</button>
        </div>
      </div>
    );
}