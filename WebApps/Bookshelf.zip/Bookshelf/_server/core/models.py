from django.db import models

# Create your models here.
from django.contrib.auth.models import User

class Book(models.Model):
    id = models.BigAutoField(primary_key=True)
    title = models.TextField()
    review = models.TextField()
    rating = models.IntegerField()
    background_color = models.CharField(max_length=7) 
    text_color = models.CharField(max_length=7) 
    border_color = models.CharField(max_length=7) 
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    share_publicly = models.BooleanField()
    has_Read = models.BooleanField()
    author = models.TextField()

class Preferences(models.Model):
    ide = models.BigAutoField(primary_key=True)
    preference = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
