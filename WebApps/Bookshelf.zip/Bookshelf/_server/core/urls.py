from django.urls import path
from . import views

urlpatterns = [
    path('', view=views.index, name="index"),
    path('me/', view=views.me, name="current user"),
    path("books/", view=views.books, name="books"),
    path("books/<int:id>/", view=views.book, name="book"),
    path("delete/<int:id>/", view=views.delete, name="delete"),
    path("update/<int:id>/", view=views.update, name="update"),
]