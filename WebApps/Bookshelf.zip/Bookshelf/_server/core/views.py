from django.shortcuts import render
from django.conf  import settings
import json
import os
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.forms.models import model_to_dict
import requests
from .models import Book, Preferences

# Load manifest when server launches
MANIFEST = {}
if not settings.DEBUG:
    f = open(f"{settings.BASE_DIR}/core/static/manifest.json")
    MANIFEST = json.load(f)

# Create your views here.
@login_required
def index(req):
    context = {
        "asset_url": os.environ.get("ASSET_URL", ""),
        "debug": settings.DEBUG,
        "manifest": MANIFEST,
        "js_file": "" if settings.DEBUG else MANIFEST["src/main.ts"]["file"],
        "css_file": "" if settings.DEBUG else MANIFEST["src/main.ts"]["css"][0]
    }
    return render(req, "core/index.html", context)

@login_required
def get_book_rec(req):
    # pref = Preferences.preference
    url="https://www.googleapis.com/books/v1/volumes?q={Preferences.preference}+subject:keyes&key=AIzaSyCrtJCYjGWZ3Rt3-mCdy2m2YtVavE8_-ts"

    response = requests.get(url)

    print(response.text)


@login_required
def books(req):
    if req.method == "POST":
        body = json.loads(req.body)
        book = Book(
            title=body["title"], 
            review=body["review"],
            rating=body["rating"],
            background_color=body["background_color"],
            text_color=body["text_color"],
            border_color=body["border_color"],
            user=req.user,
            author=body["author"],
            share_publicly=body["share_publicly"],
            has_Read=body["has_Read"]

        )
        book.save()
        return JsonResponse({"book": model_to_dict(book)})
    
    books = [model_to_dict(book) for book in req.user.book_set.all()]
    return JsonResponse({"books": books})

@login_required
def book(req, id):
    book = req.user.book_set.get(id=id)
    return JsonResponse({"book": model_to_dict(book)})

@login_required
def update(req, id):
    body = json.loads(req.body)
    book = req.user.book_set.get(id=id)
    book.title = body["title"]
    book.review =body["review"]
    book.rating=body["rating"]
    book.background_color=body["background_color"]
    book.text_color=body["text_color"]
    book.border_color=body["border_color"]
    book.author=body["author"]
    book.share_publicly=body["share_publicly"]
    book.has_Read=body["has_Read"]
    

    book.save()
    return JsonResponse({"book": model_to_dict(book)})

@login_required
def delete(req,id):
    book = req.user.book_set.get(id=id)
    book.delete()
    return JsonResponse({"book": model_to_dict(book)})


@login_required
def me(req):
    return JsonResponse({"user": model_to_dict(req.user)})