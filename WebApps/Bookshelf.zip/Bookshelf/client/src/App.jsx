import { useState, useEffect } from 'react'
import './App.css'
import cookie from "cookie";
import { Link, Outlet } from 'react-router-dom';

function App() {
  const [user, setUser] = useState(null);

  async function getUser(){
    const res = await fetch('/me/', {
      credentaials: "same-origin",
    });
    const body = await res.json();
    setUser(body.user)
  }

  useEffect(() => {
    getUser();
  }, [])

  async function logout() {
    const res = await fetch("/registration/logout/", {
      credentials: "same-origin", // include cookies!
    });

    if (res.ok) {
      // navigate away from the single page app!
      window.location = "/registration/sign_in/";
    } else {
      // handle logout failed!
    }
  }

  if(!user){
    return <div>Loading</div>
  }
  return (
    <>
      <nav className="navbar">
        <div className="nav-header">
            <h2>{user.first_name}'s Bookshelf</h2>
        </div>
        <div className="links">
          <Link className='pageLink' to='/bookRec'>Book Recomendation</Link>
          <Link className='pageLink' to=''>My Books</Link>
          <Link className='pageLink' to='/readingList'>Reading List</Link>
          <Link className='pageLink' onClick={logout}>Logout</Link>
        </div>
        </nav>

        <div><Outlet/></div>
    </>
  
  )
}

export default App;
