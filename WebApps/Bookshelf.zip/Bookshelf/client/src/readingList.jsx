import { useState, useEffect } from "react";
import { Link } from "react-router-dom"

export function ReadingList(){
    const [books, setBooks] = useState([]);

    async function getBooks(){
        const res = await fetch("/books/", {
          credentials: "same-origin",
        })
        const body = await res.json();
        const filteredBooks = body.books.filter(book => !book.has_Read);

        setBooks(filteredBooks)
      }


      useEffect(() => {
        getBooks();
      }, [])

    async function removeBook(bookid){
        const res = await fetch(`/delete/${bookid}/`, {
            credentials: "same-origin",
          })
        setBooks(books.filter(b => b.id != bookid))
    }
    return(
        <div className="page">
            <h2>Take a book off the shelf!</h2>
            
            <div className="bookList">
                {
                    books.map((book) => {
                    let className = "book"
                    let text = book.text_color;
                    let background = book.background_color;
                    let border = book.border_color;
                    return(
                        <div key={book.id} className={className} style={{ color: text, backgroundColor: background, borderColor: border }}>
                            <Link  className="bookTitle" style={{borderColor: border, color: text, textDecoration: "none"}} to={`/book/${book.id}/`} >
                                <div style={{textDecoration: "none"}}>{book.title}</div>
                            </Link>
                            <div className="author"> {book.author}</div>
                            <button onClick={ () => removeBook(book.id)}>I don't want to read this anymore</button>
                        </div>
                    )
                    })
                }
            </div>

            <Link className="addBook" to="/newBook">Add</Link>
        </div>
    )
}