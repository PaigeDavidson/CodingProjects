import { useState, useEffect } from "react";
import cookie from "cookie";
import { useNavigate } from "react-router-dom";

export function NewBook(){
    const [title, setTitle] = useState("");
    const [review, setReview] = useState("");
    const [rating, setRating] = useState(0);
    const [background_color, setBackground] = useState("#ffffff");
    const [text_color, setText] = useState("#000000");
    const [border_color, setBorder] = useState("#ffffff");
    const [author, setAuthor] = useState("");
    const [share_publicly, setShare] = useState(false);
    const [has_Read, setRead] = useState(false);

    const navigate = useNavigate();

    async function createBook(e){
        e.preventDefault();
        const res = await fetch("/books/", {
            method: "post",
            credentials: "include",
            body: JSON.stringify({
                title, 
                review,
                rating,
                background_color,
                text_color,
                border_color,
                author,
                share_publicly,
                has_Read
            }),
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": cookie.parse(document.cookie).csrftoken
            }
        });
        const body = await res.json();
        navigate(-1);


    }
    return(
        <div className="page">
            <form onSubmit={createBook} className="readBook">
                Book Title
                <input type="text" placeholder={title} value={title} onChange={e => setTitle(e.target.value)}/>
                Book Author
                <input type="text" placeholder={author} value={author} onChange={e => setAuthor(e.target.value)}/>
                Review
                <input type="text" placeholder={review} value={review} onChange={e => setReview(e.target.value)}/>
                Rating
                <input type="int" placeholder={rating} value={rating} onChange={e => setRating(e.target.value)}/>
                Book Color
                <input type="color" placeholder={background_color} value={background_color} onChange={e => setBackground(e.target.value)}/>
                Text Color 
                <input type="color" placeholder={text_color} value={text_color} onChange={e => setText(e.target.value)}/>
                Border Color 
                <input type="color" placeholder={border_color} value={border_color} onChange={e => setBorder(e.target.value)}/>

                <input type="checkbox" name="has_Read" id="has_Read" onChange={e => setRead(e.target.checked)}/>
                <label htmlFor="has_Read">Finished?</label>

                <button type="submit">Create My book!</button>
            </form>
        </div>
        
    )
}