import { useState } from "react";

export function BookRec() {
    const [keyword, setKeyword] = useState('');
    const [book, setBook] = useState(null);
  
    const handleSearch = async (event) => {
      event.preventDefault();
  
      try {
        const response = await fetch(
          `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(
            keyword
          )}&maxResults=1&key=AIzaSyCrtJCYjGWZ3Rt3-mCdy2m2YtVavE8_-ts`
        );
  
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
  
        const data = await response.json();
  
        const firstBook = data.items[0];
        setBook(firstBook ? firstBook.volumeInfo : null);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    return (
      <div className="page">
        <h1>Book Recommendation</h1>
        <form onSubmit={handleSearch}>
          <label>
            Enter Keyword:
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
            />
          </label>
          <button type="submit">Search</button>
        </form>
        {book && (
          <div className="recommended">
            <h3>{book.title}</h3>
            <p>{book.authors && book.authors.join(', ')}</p>
          </div>
        )}
      </div>
    );
  }
