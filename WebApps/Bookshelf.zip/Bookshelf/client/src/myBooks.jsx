import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

export function MyBooks(){
    const [books, setBooks] = useState([]);

    async function getBooks(){
        const res = await fetch("/books/", {
          credentials: "same-origin",
        })
        const body = await res.json();
        const filteredBooks = body.books.filter(book => book.has_Read);

        setBooks(filteredBooks)
      }

      useEffect(() => {
        getBooks();
      }, [])
    
    return(
        <div className="page">
            
            <div className="bookList">
                {
                    books.map((book) => {
                    let className = "book"
                    let text = book.text_color;
                    let background = book.background_color;
                    let border = book.border_color;
                    return(
                        <Link key={book.id} to={`/book/${book.id}/`} className={className} style={{ color: text, backgroundColor: background, borderColor: border }}>
                            <div className="bookTitle" style={{borderColor: border}}>{book.title}</div>
                            <div className="author">{book.author}</div>
                            <div className="rating">Rating: {book.rating}/10</div>
                            <div className="review">Review: {book.review}</div>
                        </Link>
                    )
                    })
                }
            </div>

            <Link className="addBook" to="/newBook">Add</Link>
        </div>
    )
}