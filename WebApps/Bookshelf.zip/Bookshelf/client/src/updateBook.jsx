import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import cookie from "cookie";


export function UpdateBook(){
    const [title, setTitle] = useState("");
    const [review, setReview] = useState("");
    const [rating, setRating] = useState(0);
    const [background_color, setBackground] = useState("#ffffff");
    const [text_color, setText] = useState("#000000");
    const [border_color, setBorder] = useState("#ffffff");
    const [author, setAuthor] = useState("");
    const [share_publicly, setShare] = useState(false);
    const [has_Read, setRead] = useState(false);

    const[book, setBook] = useState(null);
    const params = useParams();
    const navigate = useNavigate();

    async function updateBook(e){
        e.preventDefault();
        const res = await fetch(`/update/${params.id}/`, {
            method: "post",
            credentials: "include",
            body: JSON.stringify({
                title, 
                review,
                rating,
                background_color,
                text_color,
                border_color,
                author,
                share_publicly,
                has_Read
            }),
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": cookie.parse(document.cookie).csrftoken
            }
        })
        if(res.ok){
            navigate(-1);
        }
    }
    async function getBook(){
        try {
            const res = await fetch(`/books/${params.id}/`, {
              credentials: "same-origin",
            });
      
            if (res.ok) {
              const body = await res.json();
              setBook(body.book);
      
              // Prepopulate form fields with book parameters
              setTitle(body.book.title);
              setReview(body.book.review);
              setRating(body.book.rating);
              setBackground(body.book.background_color);
              setText(body.book.text_color);
              setBorder(body.book.border_color);
              setAuthor(body.book.author);
              setShare(body.book.share_publicly);
              setRead(body.book.has_Read);
            } else {
              console.error('Error fetching book:', res.status, res.statusText);
              // Handle error, show a message to the user, etc.
            }
          } catch (error) {
            console.error('Error fetching book:', error);
          }
      }

    useEffect(() => {
        getBook();
      }, [params.id])
      
    return(
        <div className="page">
        <form onSubmit={updateBook} className="readBook">
            Book Title
            <input type="text" value={title} onChange={e => setTitle(e.target.value)}/>
            Book Author
            <input type="text" value={author} onChange={e => setAuthor(e.target.value)}/>.
            Review
            <input type="text" value={review} onChange={e => setReview(e.target.value)}/>
            Rating
            <input type="int" value={rating} onChange={e => setRating(e.target.value)}/>
            Book Color
            <input type="color" value={background_color} onChange={e => setBackground(e.target.value)}/>
            Text Color 
            <input type="color" value={text_color} onChange={e => setText(e.target.value)}/>
            Border Color 
            <input type="color" value={border_color} onChange={e => setBorder(e.target.value)}/>

            <input type="checkbox" name="has_Read" id="has_Read" checked={has_Read} onChange={e => setRead(e.target.checked)}/>
            <label htmlFor="has_Read">Finished?</label>

            <button type="submit">Update</button>
        </form>
    </div>
    )
  }