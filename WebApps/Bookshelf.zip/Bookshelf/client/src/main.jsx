import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import 'vite/modulepreload-polyfill'
import { MyBooks } from './myBooks.jsx'
import {createHashRouter, RouterProvider} from 'react-router-dom'
import { NewBook } from './newBook.jsx'
import { ReadingList } from './readingList.jsx'
import { BookRec } from './bookRec.jsx'
import { UpdateBook } from './updateBook.jsx'
const router = createHashRouter([
    {
        path: "", 
        element: <App/>, 
        children: [
            {
                path: "",
                element: <MyBooks/>
            },
            {
                path: "/newBook",
                element: <NewBook/>
            },
            {
                path:"/readingList",
                element: <ReadingList/>
            },
            {
                path: "/bookRec",
                element: <BookRec/>
            },
            {
                path: "/book/:id",
                element: <UpdateBook/>
            },
        ]
    }
])


ReactDOM.createRoot(document.getElementById('root')).render(
    <RouterProvider router={router}/>
)
