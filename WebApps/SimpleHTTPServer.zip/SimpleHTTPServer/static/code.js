// just do anything in here it doesnt really matter as long as its in java script
console.log("Hello from JavaScript");