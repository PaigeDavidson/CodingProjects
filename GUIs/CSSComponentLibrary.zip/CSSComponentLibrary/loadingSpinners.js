document.getElementById("spinner-html1").innerText = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="yourCSSFile.css">
    <title>Document</title>
</head>
<body>
    
    <div class="example1">
        <div class="one"></div>
        <div class="two"></div>
        <div class="three"></div>
    </div>

</body>
</html>
`;

document.getElementById("spinner-html2").innerText = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="yourCSSFile.css">
    <title>Document</title>
</head>
<body>
    
    <div class="example2">
        Loading
    </div>

</body>
</html>
`;

document.getElementById("spinner-html3").innerText = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="yourCSSFile.css">
    <title>Document</title>
</head>
<body>
    <div class="margin">
        <div class="example3"></div>
        <div class="example3"></div>
        <div class="example3"></div>
    </div>

</body>
</html>
`;