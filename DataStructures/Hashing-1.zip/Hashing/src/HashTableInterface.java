import java.io.BufferedReader;

interface HashTableInterface{
    public void insertAll(BufferedReader sc,int size) ;
    public void findAll(BufferedReader sc, String msg) ;
    public String toString(int limit);
}