/**
 * Interface used by Schedulers to report scheduling events
 */
public interface Logger {
    void log(String message);
}
