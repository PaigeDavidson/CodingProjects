import java.util.LinkedList;
import java.util.HashMap;

public class ParallelPi {
    final static int NUM_DIGITS = 1000;

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();

        TaskQueue taskQueue = new TaskQueue(ParallelPi.NUM_DIGITS);
        ResultTable resultTable = new ResultTable();

        // Create worker threads
        WorkerThread[] threads = new WorkerThread[Runtime.getRuntime().availableProcessors()];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new WorkerThread(taskQueue, resultTable);
            threads[i].start();
        }

        // Join threads
        for (WorkerThread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Print computed value of Pi
        StringBuilder piDigits = new StringBuilder();
        for (int i = 1; i <= NUM_DIGITS; i++) {
            char digit = resultTable.getResult(i);
            piDigits.append(digit);
            if (i % 10 == 0) {
                System.out.print(".");
                System.out.flush();
            }
        }
        System.out.println();

        long endTime = System.currentTimeMillis();
        System.out.println("Computed value of Pi: " + piDigits);
        System.out.println("Total time: " + (endTime - startTime) + " ms");
    }
}
class TaskQueue {
    private LinkedList<String> queue;

    public TaskQueue(int numDigits) {
        queue = new LinkedList<>();
        populateQueue(numDigits);
    }

    public void populateQueue(int numDigits) {
        for (int i = 0; i < numDigits; i++) {
            queue.add(Integer.toString(i % 10)); // Add a task for each digit to be computed
        }
    }

    public synchronized String dequeue() {
        return queue.poll();
    }

    public synchronized boolean isEmpty() {
        return queue.isEmpty();
    }
}

class ResultTable {
    private HashMap<Integer, Character> table;

    public ResultTable() {
        table = new HashMap<>();
    }

    public synchronized void putResult(int position, char digit) {
        table.put(position, digit);
    }

    public synchronized Character getResult(int position) {
        Character result = table.get(position);
        return result != null ? result : '0'; // Return '0' if result is null
    }
}

class WorkerThread extends Thread {
    private TaskQueue taskQueue;
    private ResultTable resultTable;
    private Bpp bpp;

    public WorkerThread(TaskQueue taskQueue, ResultTable resultTable) {
        this.taskQueue = taskQueue;
        this.resultTable = resultTable;
        this.bpp = new Bpp();
    }

    @Override
    public void run() {
        while (true) {
            String task = taskQueue.dequeue();
            if (task == null) {
                break;
            }
            char digit = computeDigit(task);
            int position = Integer.parseInt(task);
            resultTable.putResult(position, digit);
            if (position % 10 == 0) {
                System.out.print(".");
                System.out.flush();
            }
        }
    }

    private char computeDigit(String task) {
        long decimalValue = bpp.getDecimal(Long.parseLong(task));
        if (decimalValue == 0) {
            return '0';
        }
        return (char) (decimalValue % 10 + '0');
    }
}



