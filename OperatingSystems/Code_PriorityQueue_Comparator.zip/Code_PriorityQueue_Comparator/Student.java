class Student{
    String firstName;
    String lastName;
    int aNumber;

    public Student(String fName, String lName, int num){
        this.firstName = fName;
        this.lastName = lName;
        this.aNumber = num;
    }
}